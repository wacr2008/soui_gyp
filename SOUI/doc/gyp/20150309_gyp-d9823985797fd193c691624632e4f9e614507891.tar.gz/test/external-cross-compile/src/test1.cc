From test1.cc
