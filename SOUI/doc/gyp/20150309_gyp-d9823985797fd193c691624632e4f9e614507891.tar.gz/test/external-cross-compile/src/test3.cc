From test3.cc
