#!/bin/bash

set -e

test -f ${CHROMIUM_STRIP_SAVE_FILE}
