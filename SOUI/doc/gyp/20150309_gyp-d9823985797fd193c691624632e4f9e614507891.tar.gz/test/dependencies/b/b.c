int funcB() {
  return 2;
}
