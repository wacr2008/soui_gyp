#define INC_STRING "subdir/inc.h"
